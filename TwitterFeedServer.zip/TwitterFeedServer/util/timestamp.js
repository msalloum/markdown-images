function getCurrentTimestamp() {
    return new Date().toLocaleTimeString();
}

module.exports = {
  getCurrentTimestamp
};
